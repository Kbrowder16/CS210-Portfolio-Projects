// CS 210 - Project One: Chada Tech Clocks
// Developer: Kristina Browder
// Description: This program simulates both 12-hour and 24-hour clocks with user menu input.

#include <iostream>
#include <iomanip>

using namespace std;

// Function Prototypes
void displayClocks(int, int, int);
void displayMenu();
void addOneHour(int&, int&, int&);
void addOneMinute(int&, int&, int&);
void addOneSecond(int&, int&, int&);

int main() {
    // Initialize time variables
    int hour = 0;
    int minute = 0;
    int second = 0;

    int choice;

    while (true) {
        displayClocks(hour, minute, second);
        displayMenu();
        cin >> choice;

        switch (choice) {
        case 1:
            addOneHour(hour, minute, second);
            break;
        case 2:
            addOneMinute(hour, minute, second);
            break;
        case 3:
            addOneSecond(hour, minute, second);
            break;
        case 4:
            cout << "Exiting program. Goodbye!" << endl;
            return 0;
        default:
            cout << "Invalid selection. Please choose again." << endl;
        }
    }
    return 0;
}

// Function to display clocks
void displayClocks(int h, int m, int s) {
    // Format for 12-hour clock
    int hour12 = h % 12;
    string am_pm = (h >= 12) ? "PM" : "AM";
    if (hour12 == 0) hour12 = 12;

    cout << "**************************     **************************" << endl;
    cout << "*    12-Hour Clock      *     *     24-Hour Clock      *" << endl;
    cout << "*     "
        << setw(2) << setfill('0') << hour12 << ":"
        << setw(2) << setfill('0') << m << ":"
        << setw(2) << setfill('0') << s << " " << am_pm
        << "     *     *     "
        << setw(2) << setfill('0') << h << ":"
        << setw(2) << setfill('0') << m << ":"
        << setw(2) << setfill('0') << s
        << "         *" << endl;
    cout << "**************************     **************************" << endl;
}

// Menu options
void displayMenu() {
    cout << endl;
    cout << "**************************" << endl;
    cout << "* 1 - Add One Hour       *" << endl;
    cout << "* 2 - Add One Minute     *" << endl;
    cout << "* 3 - Add One Second     *" << endl;
    cout << "* 4 - Exit Program       *" << endl;
    cout << "**************************" << endl;
    cout << "Enter choice: ";
}

// Time modification functions
void addOneHour(int& h, int& m, int& s) {
    h = (h + 1) % 24;
}
void addOneMinute(int& h, int& m, int& s) {
    m++;
    if (m >= 60) {
        m = 0;
        addOneHour(h, m, s);
    }
}
void addOneSecond(int& h, int& m, int& s) {
    s++;
    if (s >= 60) {
        s = 0;
        addOneMinute(h, m, s);
    }
}
